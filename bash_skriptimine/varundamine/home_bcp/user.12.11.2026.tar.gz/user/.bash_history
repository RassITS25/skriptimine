su -
su -
sudo whoami
restart
reboot
sudo reboot
su -
sudo whoami
su -
cd skriptimine/
whoami
whoami | cut -cl | tr [:lower:] [:upper:]
whoami | cut -c1 | tr [:lower:] [:upper:]
whoami | cut -c1 | tr [:lower:] [:upper:] | echo
echo 'testing'
echo ´tura`
echo $tura)
echo (whoami | cut -c1 | tr [:lower:] [:upper:])
echo $(whoami | cut -c1 | tr [:lower:] [:upper:])
echo $(whoami | "cut -c1" | tr [:lower:] [:upper:])
echo $(whoami | cut -c3 | tr [:lower:] [:upper:])
echo $(whoami | cut -c2 | tr [:lower:] [:upper:])
echo $(whoami | cut -c3 | tr [:lower:] [:upper:])
echo $(whoami | cut -c4 | tr [:lower:] [:upper:])
echo $(whoami | cut -c2- | tr [:lower:] [:upper:])
echo $(whoami | cut -c2- )
echo $(whoami | cut -c2- ) | cut -c1 )
echo $(whoami | cut -c2- ) | cut -c1 |)
echo -n $(whoami | cut -c2- ) | cut -c1 |)
echo -n $(whoami | cut -c2- )
cd skriptimine/
ls -l
cd praks1/
nano git_kasutamine 
apt-get update
sudo apt-get update
apt-get install git
sudo apt-get install git
which git
ls
ls -l
where
mkdir skriptimine
cd skriptimine/
git config --global user.name "Rasmus Mäepalo"
git config --global user.email rasmus.maepalo@voco.ee
git config --global core.editor nano
git init
mkdir praks1
cd praks1/
touch git_kasutamine
nano git_kasutamine 
git log
git config --global user.name "RassITS25"
nano git_kasutamine 
ssh-keygen -t ed25519 -C "rasmus.maepalo@voco.ee"
cat /home/user/.ssh/id_ed25519.pub 
git remote add skriptimine git@github.com:RassITS25/skriptimine.git
git remote -v
git add git_kasutamine 
git commit -m "esimene commit"
git push -uf skriptimine master
nano git_kasutamine 
git remote -v
git add git_kasutamine 
git commit -m "lisatud remote seadistus"
git push -uf skriptimine master
git remote add skriptimine git@github.com:RassITS25/skriptimine.git
nano git_kasutamine 
git add git_kasutamine
git push -uf skriptimine master
git commit -m "lisatud põhikasutamine"
git push -uf skriptimine master
cd skriptimine/
echo $shell
echo $SHELL
echo $HOME
echo $USER
echo $?
nano praks2
echo praks2
cat praks2
nano praks2
rm praks2
nano yl1

nano yl1
mv yl1 yl1.sh
cat yl1.sh
yl1.sh
nano yl1.sh

cat yl1.sh
nano yl1.sh
cat yl1.sh
chmod +x yl1.sh
./yl1.sh
git add yl1.sh
git push -uf skriptimine master
git init
git commit -m "ülesanne1"
git push -uf skriptimine master
ls -l
mkdir praks2
mv yl1.sh /praks2
ls -l
mv yl1.sh praks2/
ls -l praks2/
git add praks2
git commit -m "ülesanne2"
git push -uf skriptimine master
cd praks2
touch yl3.sh
nano yl3.sh 
chmod +x yl3.sh
nano yl3.sh 
./yl3.sh
sudo apt install ncal
./yl3.sh
nano yl3.sh 
sudo apt install ncal
./yl3.sh
git add praks2
git add yl3.sh
git commit -m "Ülesanne 3"
git push -uf skriptimine master
cd skriptimine/
ls -l
cd praks2
ls -l
cd ..
mkdir praks3
cd praks3
touch tervitus.sh
nano tervitus.sh 
chmod +x tervitus.sh 
./tervitus.sh
nano tervitus.sh 
mv tervitus.sh yl1.sh
./yl1.sh
nano yl2.sh
chmod +x yl2.sh 
./yl2.sh
nano yl2.sh
./yl2.sh
cd ..
git add praks3
git commit -m "Praks3"
git push -uf skriptimise master
git push -uf skriptimine master
cd praks3
touch yl3.sh
nano yl3.sh 
chmod +x yl3.sh 
./yl3.sh 
nano yl3.sh 
git push yl3.sh
cd ..
git add praks3
git commit -m "ül3praks3"
git push -uf skriptimine master
sudo whoami
dpkg -- list | grep git
dpkg --list | grep git
apt-get install git
ip a
cd skriptimine/
ls -l
cd praks1
ls -l
cd ..
ls -l
git init
cd ..
history
'histori | more
'histori | less
history | less
ip a
git status
cd skriptimine/
git status
mkdir praks4
cd praks4
nano yl1.sh
chmod +x yl1.sh
./yl1.sh
touch yl2.sh
nano yl2.sh 
chmod +x yl2.sh
./yl2.sh
nano yl3.sh
chmod +x yl3.sh
./yl3.sh
nano yl3.sh
./yl3.sh
nano yl4.sh
cdp yl1.sh yl4.sh
cp yl1.sh yl4.sh
nano yl4.sh
chmod +x yl4.sh
./yl4.sh
nano yl4.sh
./yl4.sh
nano yl4.sh
./yl4.sh
nano lisayl.sh
cd ..
cd praks2
ls -l
cd ..
cd praks4
nano lisayl.sh 
chmod +x lisayl.sh 
./lisayl.sh 
nano lisayl.sh 
./lisayl.sh 
nano lisayl.sh 
./lisayl.sh 
nano lisayl.sh 
./lisayl.sh 
cd ..
git add praks4
git commit -m "Praks4"
git push -uf skriptimine master
cd praks4
nano lisayl.sh 
cd skriptimine/
mkdir praks5
cd praks5
touch yl1.sh
nano yl1.sh 
chmod +x yl1.sh 
./yl1.sh 
nano yl1.sh 
./yl1.sh 
./yl1.sh
nano yl1.sh 
./yl1.sh
nano yl1.sh 
./yl1.sh
nano yl2.sh
chmod +x yl2.sh 
./yl2.sh 
nano yl3.sh
chmod +x yl3.sh 
./yl3.sh 
nano yl4.sh
chmod +x yl4.sh 
./yl4.sh 
cd ..
git commit -m "praks5"
git add praks5
git commit -m "praks5"
git push -uf skriptimine master
git rm yl1.sh
git push
ls -l
ip a
cd skriptimine/
cd praks6
nano yl1.sh
chmod +x yl1.sh
./yl1.sh
nano yl1.sh
./yl1.sh
cp yl1.sh yl2.sh
ls -l
nano yl2.sh
./yl2.sh
nano yl2.sh
./yl2.sh
nano yl2.sh
./yl2.sh
nano yl2.sh
nano e.sh
chmod +x e.sh
./e.sh 
rm e.sh 
nano yl2.sh 
nano yl1.sh 
./yl1.sh 
nano yl1.sh 
rm yl2.sh 
cp yl1.sh yl2.sh
nano yl2.sh 
./yl2.sh 
nano yl2.sh 
cp yl2.sh yl3.sh
nano yl3.sh 
./yl3.sh 
nano yl3.sh 
./yl3.sh 
nano yl3.sh 
rm yl3.sh 
nano yl3.sh
chmod +x yl3.sh 
./yl3.sh 
chmod +x yl3.sh 
nano yl3.sh
rm yl3.sh 
nano yl3.sh
chmod +x yl3.sh 
./yl3.sh 
nano yl3.sh
./yl3.sh 
cd skriptimine/
mkdir praks6
cd praks6
nano yl1.sh
ip a
cd skriptimine/
ls -l
cd praks6
ls -l
nano yl3.sh 
nano yl1.sh 
./yl1.sh 
./yl2.sh 
./yl3.sh 
cd ..
cp praks6 praks7
mv praks6 praks7
cd praks7
nano yl4.sh
chmod +x yl4.sh 
./yl4.sh 
nano yl5.sh
chmod +x yl5.sh 
./yl5.sh 
cd ..
git add praks7
git commit -m praks7
git push -uf skriptimine master
mkdir lisa_ylesanded
cd lisa_ylesanded/
cd ..
ls -l
cd lisa_ylesanded/
nanoe onnenumbrid.sh
nano onnenumbrid.sh
chmod +x onnenumbrid.sh 
./onnenumbrid.sh 
nano tag.sh
chmod +x tag.sh 
./tag.sh 
nano tag.sh
./tag.sh 
touch loto.sh
nano loto.sh 
chmod +x loto.sh 
./loto.sh 
ls -l
cat tulemused.txt 
rm tulemused.txt 
ls -l
nano loto.sh 
./loto.sh 
nano vorrand.sh
chmod +x vorrand.sh 
./vorrand.sh 
nano vorrand.sh 
./vorrand.sh 
nano vorrand.sh 
./vorrand.sh 
./vorrand.sh 1 7 5
sudo apt install bc
./vorrand.sh 3 7 2
./vorrand.sh 3 -7 22
./vorrand.sh 1 3 9
./vorrand.sh 3 3 9
./vorrand.sh 3 7 9
./vorrand.sh 3 7 2
./vorrand.sh 3 7 4
cd ..
git add lisa_ylesanded/
gir commit -m lisa_ylesanded
git commit -m lisa_ylesanded
git push -uf skriptimine master
nano README.md
git add README.md 
gir commit -m readme
git commit -m readme
git push -uf skriptimine master
nano README.md
git push -uf skriptimine master
git commit -m readme
nano README.md
git push -uf skriptimine master
sudo apt install tree
cd skriptimine/
tree
sl
ls
ls -l
mkdir work
cd work/
touch hello.html
nano hello.html 
cd ..
rm -f work/
rmdir work/
rmdir -f work/
cd work/
cd ..
cd work/
rm hello.html 
cd ..
rmdir work/
mkdir git_howto
cd git_howto/
nano hello.html
cd ..
git add git_howto/
git commit -m githowto
git push -uf skriptimine master
cd git_howto/
nano hello.html 
git status
git add hello.html 
git status
touch a.html
touch b.html
touch c.html
git add a.html 
git add b.html 
git commit -m "a ja b"
git add c.html 
git ocmmit -m "c"
git commit -m "c"
git commit
git status
nano hello.html 
git add hello.html 
nano hello.html 
git status
git commit -m "html"
git add .
git status
git commit -m "html head"
git log
git log --oneline
git log --oneline --max-count=2
git log --oneline --since="5 minutes ago"
git log --oneline --until="5 minutes ago"
git log --oneline --author="user"
git log --oneline --author="RassITS25"
git log --oneline -all
git log --all --pretty=format:"%h %cd %s (%an)" --since="7 days ago"
git log --pretty=format:"%h %ad | %s%d [%an]" --date=short
git config --global format.pretty '%h %ad | %s%d [%an]'
git config --global log.date short
git log
git checkout <hash>
cat hello.html
git switch main
git tag v1
git log
git checkout v1^
cat hello.html 
git checkout v1
git checkout v1-beta
git tag
git log main --all
git switch main
nano hello.html 
git status
git restore hello.html
git status 
cat hello.html 
nano hello.html 
git add hello.html 
git sta
git status
git restore --staged hello.html 
git restore hello.html 
git status
nano hello.html 
git add hello.html 
git commit -m "woopsie daisies"
git revert HEAD
git log
git tag oops
git reset --hard v1
git log
git log --all
git tag -d oops
git log --all
nano hello.html 
git add hello.html 
git commit -m "copyright"
git log
nano hello.html 
git add hello.html 
git commit -amend -m "copyright grrr"
git commit --amend -m "copyright grrr"
git log
git switch -c style
git status
touch style.css
nano style.css 
git add style.css 
git commit -m "css style"
nano hello.html 
git add hello.html 
git commit -m "include stylesheet"
git switch main
cat hello.html 
git switch style 
cat hello.html 
git log hello.html
git log style 
git log style.css
git show vc1
git show v1
mv hello.html index.html
git status
git add .
git status
mkdir css
git mv style.css css/style.css
git status
git commit- m "hello rename, move style"
git commit -m "hello rename, move style"
git log css/style.css
git log --follow css/style.css
git switch main
git add README
nano README
git switch main
git add README 
git commit -m "readme"
$git log --all --graph
git switch style
git merge main
git log --all --graph
$git switch main
git switch main
nano index.html 
nano hello.html
ls -l
nano index.html 
git add index.html 
git commit -m "added metatitle"
git log --all --graph
git switch style
git switch main
git branch
git master
ls -l
git switch style
git merge master
git status
git merge --abort
git status
git merge master
git add index.html
git commit -m "blablabla"
git branch
git switch master
ls -l
cd ..
git switch master
cd git_howto/
git status
git log --all --graph
git status
git switch style
git log --graph
git reset --hard HEAD~2
git log --graph
git switch st yle
git switch style
git rebase main
git rebase master
git status
git add .
git rebase --continue
git status
git log --all --graph
git switch master
git branch
git merge style
git log --all --graph
cd .
cd ..
git rm git_howto
git rm -r git_howto
git commit -m "removed git_howto"
git push origin master
git push skritpimine  master
git push -uf skritpimine  master
rm -r git_howto
git push origin master
git remote -v
git push skriptimine master
cd skriptimine/
ls -l
tree
cd ..
ls
cd skriptimine/
mkdir bash_skriptimine
cd bash_skriptimine/
mkdir funktsioonid
cd funktsioonid/
nano funktsioonid.sh
nano loto.sh
chmod +x loto.sh 
./loto.sh 
nano loto.sh
./loto.sh 
nano loto.sh
./loto.sh 
nano loto.sh
./loto.sh 
nano loto.sh
./loto.sh 
nano loto.sh
./loto.sh 
nano loto.sh
git add loto.sh 
cd ..
git add funktsioonid/
cd ..
git add bash_skriptimine/
git commit -m "bashskriptimine"
git push -uf skriptimine master
cd bash_skriptimine/
ls -l 
cd funktsioonid/
ls -l
mdkir loto
ls -l
mkdir loto
mv loto.sh loto/loto.sh
mv lottery_numbers.txt loto/lottery_numbers.txt
mv player_numbers.txt loto/player_numbers.txt
mv results.txt loto/results.txt
ls -l
cd loto
ls -l
cd ..
git commit -m "aa"
git add bash_skriptimine/funktsioonid/loto
git commit -m "loto kaust"
git push -uf skriptimine master
git rm loto.sh lottery_numbers.txt player_numbers.txt results.txt
cd bash_skriptimine/
git rm loto.sh lottery_numbers.txt player_numbers.txt results.txt
git commit -m "viga"
git rm funktsioonid/loto.sh
git rm funktsioonid/lottery_numbers.txt 
git rm funktsioonid/player_numbers.txt 
git rm funktsioonid/results.txt 
git commit -m "parandus"
git push -uf skriptimine master
cd funktsioonid/
cd loto/
nano loto.sh
git commit -m "parandus2"
git add loto.sh 
git commit -m "parandus2"
git push -uf skriptimine master
cd ..
mkdir loto_uuendus
cd loto_uuendus/
nano loto.sh
chmod +x loto.sh 
./loto.sh 
cd ..
mkdir loto3
cd loto3
nano files.sh
nano input.sh
nano lottery_functions.sh
nano results.sh
nano lottery.sh
chmod +x *.sh
./lottery.sh
rm lottery
ls -l
rm files.sh
rm *.sh
ls -l
rm *.txt
ls -l
nano files.sh
nano input.sh
nano lottery_functions.sh
nano results.sh
nano lottery.sh
chmod +x *.sh
./lottery.sh
mv results.sh result.sh
ls -l
./lottery.sh
cd ..
git add funktsioonid/
git commit -m "funktsioonid ja lotod"
git push -uf skriptimine master
bash history
cd ..
history
cd skriptimine/
ls -l
mkdir githowto
cd githowto/
nano README.md
rm README.md
ls -l
history | more
nano README.md
cd ..
ls -l
git switch style
ls -l
git switch master
ls -l
git switch style
cd git_howto/
ls -l
cd ..
git switch style
git switch master
ls -l
rm -rf githowto
git switch style
cd git_howto/
ls -l
nano README.md
c d..
cd ..
git push -u skriptimine style
ls -l
cd git_howto/
ls -l
cat a.html 
history 
nano README.md
git add README.md 
git commit -m "readme git howto"
git push -uf skriptimine style
nano README.md
git add README.md 
git commit -m "aaa"
git push -uf skriptimine style
ip a
cd skriptimine/
cd yl_sha256/
touch demo.txt
echo "hello" > demo.txt
sha256sum demo.txt > demo.txt.sha256
sha256sum -c demo.txt.sha256
echo "x" >> demo.txt
sha256sum -c demo.txt.sha256
cd ..
cd praks2
ls -l
mkdir backup
cd backup/
cd ..
archive="$(ls -1t ~/praks2/backup/src_*.tar.zst | head -n1)"
ARCHIVE="$(ls -1t ~/praks2/backup/src_*.tar.zst | head -n1)"
cd backup/
cd ..
ARCHIVE="$(ls -1t ~/praks2/backup/src_*.tar.zst | head -n1)"
cd praks2
cd backup/
cd .. ..
cd ..
ARCHIVE="$(ls -lt ~/praks2/backup/src_*.tar.zst 2>/dev/null | head -n1)"
cd praks2
cd backup/
ls -l
cd ..
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
cd backup/
cd
cd skriptimine/
cd praks2
cd backup/
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
ls -l
ls
sha256sum -c "$(basename "$ARCHIVE").sha256"
cd ..
ls -l
tar --zstd -cvf backup/src_$(date +%Y-%m-%d_%H-%M-%S).tar.zst yl1.sh yl3.sh
ARCHIVE="$(ls -1t ~/skriptimine/praks2/backup/src_*.tar.zst | head -n1)"
sha256sum -c "$(basename "$ARCHIVE").sha256"
echo "$ARCHIVE"
cd backup/
sha256sum -c "$(basename "$ARCHIVE").sha256"
ARCHIVE="$(ls -1t ~/skriptimine/praks2/backup/src_*.tar.zst | head -n1)"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
sha256sum -c "$(basename "$ARCHIVE").sha256"
find . -maxdepth 1 -type f -name 'src_*.tar.*' -print0 | xargs -0 
sha256sum > checksums.txt
ls -l
sha256sum > checksums.txt
sha256sum -c checksums.txt
sha256sum checksums.txt > checksums.txt.sha256
sha256sum -c checksums.txt
cd
cd skriptimine/
ls -l
git branch
cd praks2
ls -l
git checkout master
ls -l
git branch
git checkout style -- praks2/backup
ls -l
git checkout style -- backup
ls -l
git branch
git switch style
git switch master
cd ..
ls -l
cd bash_skriptimine/
ls -l
mkdir praks1
cd praks1/
nano pasgen.sh
sydo apt instell pwgen
sudo apt install pwgen
nano pasgen.sh
chmod +x pasgen.sh 
./pasgen.sh 
pwgen -s 8 -2
pwgen -s 8 -1
nano pasgen.sh 
rm -f pasgen.sh 
nano pasgen.sh
chmod +x pasgen.sh 
./pasgen.sh 
pwgen -s 8 -1
./pasgen.sh 
ls -l
sudo ./pasgen.sh kasutajad.txt
la -
LS
ls -l
fińd kasutajad.txt
ls -l
cd ..
git add bash_skriptimine/
git commit -m "bash skriptimine parandus"
git push -uf skriptimine master
touch kasutajad.txt
echo -e "päts\npeeter\npaaveö" > kasutajad.txt 
ls -l
rm kasutajad.txt 
cd bash_skriptimine/
ls -l
cd praks1/
ls -l
touch kasutajad.txt
echo -e "päts\npeeter\npaavel" > kasutajad.txt
sudo ./pasgen.sh kasutajad.txt 
nano kasutajad.txt 
sudo ./pasgen.sh kasutajad.txt 
cat loodud_kasutajad_paroolidega
cd ..
ls -l
mkdir andmete_varundamine
cd andmete_varundamine/
mkdir backup
cd backup/
touch RasmusMaepalo.docx
nano RasmusMaepalo.docx 
cd ..
c d..
cd ..
rm -f andmete_varundamine/
rm -ff andmete_varundamine/
rm -rf andmete_varundamine/
ls -l
mkdir praks2
cd praks2
mkdir src
tar -I 'zstd -19 -T0' -cf ... -C ~/praks2 src
cd ..
tar -I 'zstd -19 -T0' -cf ... -C ~/praks2 src
tar -I 'zstd -19 -T0' -cf ... -C ~/skriptimine/bash_skriptimine/praks2 src
cd praks2
ls -l
ls - 
ls -l /src
ls -l src
ar -I 'zstd -d' -tf fail.tar.zst | head -n 5.
tar -I 'zstd -d' -tf fail.tar.zst | head -n 5
cd ..
tar -I 'zstd -d' -tf fail.tar.zst | head -n 5
cd skriptimine/
ls -l
cd bash_skriptimine/
ls -l
cd praks2
ls -l
cd skriptimine/
cd bash_skriptimine/
cd praks2
nano yl.sh
cd skriptimine/
cd bash_skriptimine/
ls -l
cd funktsioonid/
ls -l
tree
cd skriptimine/
ls -il
ls -l
cd praks5
ls 
./yl1.sh 
./yl4.sh 
./yl3.sh 
cd ..
cd praks7
ls
./yl4.sh 
./yl5.sh 
./yl2.sh 
8
cd ..
cd praks3
ls 
./yl3.sh 
cd ..
ip a
history
mkdir kt
cd kt/
mkdir backups
mkdir config
mkdir lib
mkdir scripts
nano setup.sh
nano main.sh
nano REPORT.md
nano README.md
nano .gitignore
cd scripts/
nano backup.sh
nano disk_check.sh
nano health_report.sh
nano service_check.sh
nano system_info.sh
nano user_check.sh
chmod +x */.sh
sudo chmod +x *.sh`
sudo chmod +x *.sh
cd ..
cd lib/
nano common.sh
chmod +x common.sh 
cd ..
cd config/
nano settings.conf
cd ..
cd backups/
nano .gitkeep
ls
ls -l
touch .gitkeep
cd ..
tree
./setup.sh
chmod +x setup.sh
./setup.sh
chmod +x main.sh 
./main.sh 
tree
nano REPORT.md 
tree
git add scripts/
git rm scripts/
git del scripts/
git delete scripts/
git -r scripts/
ls
ls -i
ls -l
git commit -m "skriptid"
cd scripts/
git  add user_check.sh 
git commit -m "usercheck ülevaatus"
git reset
git add user_check.sh 
git commit -m "userchecki check"
cd ..
git revert
git abort
git reset
cd scripts/
ls -l
git add user_check.sh 
git commit -m "userchecki check"
git reset HEAD~1
git status
git add backup.sh 
git commit -m "backup töötav"
git add disk_check.sh
git commit -m "diskcheck"
git add health_report.sh 
git commit -m "health repo töötav"
git add service_check.sh 
git commit -m "service check"
ls -l
git add user_check.sh 
git commit -m "user check töötav"
c d..
cd ..
git add kt/ 
git commit -m "kontrolltöö, skriptimis alused. 09.10.2026"
git push -uf skriptimine master
cd kt/
cd scripts/
ls -l
nano service_check.sh 
git add service_check.sh 
git commit -m "service check täpsustus"
git push -uf skriptimine master
cd ..
ls
./main.sh 
sudo systemctl status cron
./main.sh 
history
git add REPORT.md 
git commit -m "report uuendus"
nano REPORT.md 
git add REPORT.md 
git commit -m "report uuendus"
git push -uf skriptimine master
ls -l
cd scripts/
ls -l
./backup.sh 
cd ..
cd backups/
ls -l
cd..
cd ..
git add backups/
git commit -m "backupid test ja varki"
cd skriptimine/
ls -l
mkdir yl_sha256
cd yl_sha256/
ip a
ls -l
cd skriptimine/
cd bash_skriptimine/
ls -l
cs praks
cd praks2
ls -l
cd ..
cd praks1
ls
cd ..
| more
history | more
ls
mkdir lottery
cd lottery/
cd ..
mkdir sha256_ylesanne
cd sha256_ylesanne/
touch file
sha256sum file > file.sha256
ls
ls -l
sha256sum -c file.sha256 
touch file2
sha256sum file > file2.sha256
find . -type f -maxdepth 1 -name 'file*' -print0 | xargs -0
find . -type f -maxdepth 1 -name 'file' -print0 | xargs -0
find . -type f -maxdepth 1 -name 'file' -print0 | xargs -0 sha256sum > checksums.txt
ls
cat checksums.txt 
ls -l
rm checksums.txt 
rm file
rm file2
rm file2.sha256 
rm file.sha256 
ls
touch archive.tar.zst
sha256sum archive.tar.zst > archive.tar.zst.sha256
sha256sum -c archive.tar.zst.sha256 
touch archive2.tar.zst
find . -type f -maxdepth 1 -name '*.tar.*' -print0 | xargs -0
find . -type f -maxdepth 1 -name '*.tar.*' -print0 | xargs -0 sha256sum > checksums.txt
sha256sum -c checksumsm.txt
ls
sha256sum -c checksums.txt
echo "hello" > demo.txt
sha256sum demo.txt demo.txt.sha256
ls
sha256sum demo.txt > demo.txt.sha256
sha256sum -c demo.txt.sha256 
echo "x" >> demo.txt
sha256sum -c demo.txt.sha256 
cd ..
ls -l
cd praks2
ls
rm src
rm -f src
rm -rf src
rm yl.sh.save 
cd ..
ls
cd sha256_ylesanne/
ls
cd ..
cd praks2
mkdir backup
cd backup/
cd ..
ARCHIVE="$(ls -1t ~/praks2/backup/src_*.tar.zst | head -n1)"
cd praks2
cd backup/
touch src_*.tar.zst
cd ..
ARCHIVE="$(ls -1t ~/praks2/backup/src_*.tar.zst | head -n1)"
ARCHIVE="$(ls -lt ~/praks2/backup/src_*.tar.zst 2>/dev/null | head -n1)"
cd praks2/backup/
sha256sum -c $(basename $ARCHIVE).sha256
sha256sum -c $(basename "$ARCHIVE").sha256
ls -l
rm 'src_*.tar.zst'
ARCHIVE="$(ls -lt ~/praks2/backup/src_*.tar.zst 2>/dev/null | head -n1 | awk '{print $NF}')"
ARCHIVE="$(ls -dt ~/praks2/backup/src_*.tar.zst | head -n1)"
ls
ls -l
cd ..
ARCHIVE="$(ls -dt ~/praks2/backup/src_*.tar.zst | head -n1)"
ARCHIVE="$(ls -lt ~/praks2/backup/src_*.tar.zst 2>/dev/null | head -n1 | awk '{print $NF}')"
ARCHIVE="$(ls -dt ~/praks2/backup/src_*.tar.zst | head -n1)"
ls -la ~/praks2/backup/
cd ..
cd bash_skriptimine/
cd sha256_ylesanne/
ls -l
ARCHIVE="$(ls -dt archive*.tar.zst | head -n1)"
sha256sum -c "$(basename "$ARCHIVE").sha256"
ARCHIVE="archive.tar.zst"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
sha256sum -c "$(basename "$ARCHIVE").sha256"
git branch
cd ..
rm -rf praks2
mv sha256_ylesanne/ praks2
ls
cd praks2
ls -l
mkdir backup
ls
sha256sum -c "$(basename "$ARCHIVE").sha256"
cd backup/
touch src_2026_10_16_11-03-23.tar.zst
ARCHIVE="src_2026_10_16_11-03-23.tar.zst "
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
ARCHIVE="src_2026_10_16_11-03-23.tar.zst"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
sha256sum -c "$(basename "$ARCHIVE").sha256"
find . -maxdepth 1 -type f -name 'src_*.tar.*' -print0 | xargs -0 sha256sum > checksums.txt
cd ..
cd backup/
find . -maxdepth 1 -type f -name 'src_*.tar.*' -print0 | xargs -0 sha256sum > checksums.txt
sha256sum -c checksums.txt
ls -l
rm 'src_2026_10_16_11-03-23.tar.zst .sha256' 
ls -l
find . -maxdepth 1 -type f -name 'src_*.tar.*' -print0 | xargs -0 sha256sum > checksums.txt
sha256sum -c checksums.txt
cd ..
git add praks2
git commit -m "praks2"
git push -uf skriptimine master
ls
mkdir haldus
cd haldus/
nano yl1.sh
chmod +x yl1.sh 
./yl1.sh 
./yl1.sh testkasutaja
sudo ./yll.sh testkasutaja
sudo ./yl1.sh testkasutaja
sudo ./yl1.sh benjaminnetanyahu
cd ..
git add haldus
git commit -m "haluds yl1"
git push -uf skriptimine master
cd haldus/
nano yl2.sh
chmod +x yl2
chmod +x yl2.sh 
nano kasutajad
sudo ./yl2.sh kasutajad
nano kasutajad
nano yl2.sh
nano yl2.sh 
sudo ./yl2.sh kasutajad
nano yl2.sh 
sudo ./yl2.sh kasutajad
nano lisa_kasutaja
ls -l
nano lisa_kasutaja
chmod +x lisa_kasutaja
sudo ./yl2.sh kasutajad
nano kasutajad 
sudo ./yl2.sh kasutajad
nano yl3.sh
chmod +x yl3.sh 
./yl3.sh 
nano kasutajad_paroolid
sudo ./yl3.sh kasutajad_paroolid
cd ..
git add haldus/
git commit -m "yl2 ja yl3"
git push -uf skriptimine master
ls
cd skriptimine/
ls
cd bash_skriptimine/
ls
ip a
