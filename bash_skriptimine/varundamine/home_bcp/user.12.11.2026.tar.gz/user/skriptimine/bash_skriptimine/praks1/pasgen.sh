#!/bin/bash

# kasutajate lisamise skript koos parooli genereerimisega
if [ $# -ne 1 ]; then
    echo "Kasutusjuhend: $0 kasutajad"
else
    kasutajad=$1
    if [ -f $kasutajad -a -r $kasutajad ]; then
        echo "failid on korras"
        for rida in $(cat $kasutajad)
        do
            kasutajanimi=$(echo "$rida")

            # Kontrollime, kas kasutaja on juba olemas, kui ei ole, siis luuakse
            if ! id "$kasutajanimi" &>/dev/null; then
                useradd -m "$kasutajanimi"
            fi

            # genereerime kasutajale parooli (pikkus 8 sümbolit)
            parool=$(pwgen -s 8 -1)

            # määrame genereeritud parooli kasutajale
            echo "$kasutajanimi:$parool" | chpasswd

            # salvestame logifaili
            echo "$kasutajanimi - $parool" >> loodud_kasutajad_paroolidega
        done
    else
        echo "probleem failiga $kasutajad"
    fi
# parameetrite kontrolli lõpp
fi
